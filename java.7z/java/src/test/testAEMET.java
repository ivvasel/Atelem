package test;

import javax.json.*;
import okhttp3.*;
import java.io.*;
import okio.*;
// 46220 Sagunto
// https://opendata.aemet.es/opendata/api/prediccion/especifica/municipio/diaria/23039?api_key=eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJpdmFudmFsZW5jaWEyN0BnbWFpbC5jb20iLCJqdGkiOiI0MmRjZDJmNS0wNWY0LTQwNzYtOTQzMy01NmQ5Y2MxMjIzYzgiLCJpc3MiOiJBRU1FVCIsImlhdCI6MTU4NzU1MzM5OSwidXNlcklkIjoiNDJkY2QyZjUtMDVmNC00MDc2LTk0MzMtNTZkOWNjMTIyM2M4Iiwicm9sZSI6IiJ9.QPyA3SbF5tFnQw8CBrY9EeIZj_mpAfxmpkc0P717YDc

//23039 Guarromán 


class testAEMET {   

    public static void main(String[] args) {
    	System.setProperty("javax.net.ssl.trustStore","certs/Almacen");
		OkHttpClient client = new OkHttpClient();

		//Variables
		// Clave para poder acceder a la primera petición
    	String key = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJpdmFudmFsZW5jaWEyN0BnbWFpbC5jb20iLCJqdGkiOiI0MmRjZDJmNS0wNWY0LTQwNzYtOTQzMy01NmQ5Y2MxMjIzYzgiLCJpc3MiOiJBRU1FVCIsImlhdCI6MTU4NzU1MzM5OSwidXNlcklkIjoiNDJkY2QyZjUtMDVmNC00MDc2LTk0MzMtNTZkOWNjMTIyM2M4Iiwicm9sZSI6IiJ9.QPyA3SbF5tFnQw8CBrY9EeIZj_mpAfxmpkc0P717YDc";

    	String cpro_cmun_Guar = "23039"; //Guarromán, Jaéngit s
    	String respuesta_url = "";
    	String respuesta_datos = "";


    	//Primera petición 
    	Request request_url = new Request.Builder().url("http://opendata.aemet.es/opendata/api/prediccion/especifica/municipio/diaria/"+ cpro_cmun_Guar +"?api_key="+ key).get().addHeader("cache-control", "no-cache").build();


		try{
			Response response_url = client.newCall(request_url).execute(); 
			respuesta_url = response_url.body().string();
		}catch (IOException e){
			e.printStackTrace();
		}
         System.out.println("EXITO");

         JsonReader lector_url = Json.createReader(new StringReader(respuesta_url));
         JsonObject raiz_url= lector_url.readObject();

         String url_datos = raiz_url.getString("datos");

         //String url_datos = "https://opendata.aemet.es/opendata/api/prediccion/especifica/municipio/diaria/23039?api_key=eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJpdmFudmFsZW5jaWEyN0BnbWFpbC5jb20iLCJqdGkiOiI0MmRjZDJmNS0wNWY0LTQwNzYtOTQzMy01NmQ5Y2MxMjIzYzgiLCJpc3MiOiJBRU1FVCIsImlhdCI6MTU4NzU1MzM5OSwidXNlcklkIjoiNDJkY2QyZjUtMDVmNC00MDc2LTk0MzMtNTZkOWNjMTIyM2M4Iiwicm9sZSI6IiJ9.QPyA3SbF5tFnQw8CBrY9EeIZj_mpAfxmpkc0P717YDc";

         System.out.println(url_datos);

        // Segunda petición
        Request request_datos = new Request.Builder().url(url_datos).get().addHeader("cache-control", "no-cache").build();
        try{
         	Response response_datos = client.newCall(request_datos).execute();
         	respuesta_datos = response_datos.body().string();
        }catch (IOException e){
         	System.out.println("Error en la petición de los datos: "+e);
        }
        JsonReader lector_datos = Json.createReader(new StringReader(respuesta_datos));


        // Extracción de parámetros meteorológicos
        
		JsonArray raiz_datos = lector_datos.readArray(); 


		//Temperatura
		JsonNumber temp_18 = raiz_datos.getJsonObject(0).getJsonObject("prediccion").getJsonArray("dia").getJsonObject(1).getJsonObject("temperatura").getJsonArray("dato").getJsonObject(2).getJsonNumber("value"); 
			
		//Precipitaciones
		JsonNumber precip_18 = raiz_datos.getJsonObject(0).getJsonObject("prediccion").getJsonArray("dia").getJsonObject(1).getJsonArray("probPrecipitacion").getJsonObject(5).getJsonNumber("value");

		//Viento
		JsonObject viento_18 = raiz_datos.getJsonObject(0).getJsonObject("prediccion").getJsonArray("dia").getJsonObject(1).getJsonArray("viento").getJsonObject(5);
		JsonNumber velocidad_18 = viento_18.getJsonNumber("velocidad");
		JsonString dir_18 = viento_18.getJsonString("direccion");

		//Estado del cielo
		String estado_18 = raiz_datos.getJsonObject(0).getJsonObject("prediccion").getJsonArray("dia").getJsonObject(1).getJsonArray("estadoCielo").getJsonObject(5).getString("descripcion");


		//Muestra de datos por pantalla
		System.out.println("Preicciones para el dia de mañana en Guarromán, Jaén. Entre las 12h y 18h:");
		System.out.println("La temperatura será de "+temp_18+"ºC");
		System.out.println("La probabilidad de lluvia sera del "+precip_18+"%");
		System.out.println("El viento soplará en dirección "+dir_18+", con una velocidad de "+velocidad_18+"km/s");
		System.out.println("Estado: "+estado_18);


		//JsonNumber temperatura_PAZ = raiz.getJsonObject(0).getJsonObject("prediccion").getJsonArray("dia").getJsonObject(1).getJsonObject("temperatura").getJsonArray("dato").getJsonObject(2).getJsonNumber("value"); LUIS
        
       

    }
}

/*  System.setProperty("javax.net.ssl.trustStore", "certs/Almacen);
javac -d bin -cp "paquetes/*" src/test/testAEMET.java
java -cp "bin;paquetes/*" test.testAEMET

*/