package test;

import javax.json.*;
import okhttp3.*;
import java.io.*;
import okio.*;
// 46220 Sagunto
// https://opendata.aemet.es/opendata/api/prediccion/especifica/municipio/diaria/46220?api_key=eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJpdmFudmFsZW5jaWEyN0BnbWFpbC5jb20iLCJqdGkiOiI0MmRjZDJmNS0wNWY0LTQwNzYtOTQzMy01NmQ5Y2MxMjIzYzgiLCJpc3MiOiJBRU1FVCIsImlhdCI6MTU4NzU1MzM5OSwidXNlcklkIjoiNDJkY2QyZjUtMDVmNC00MDc2LTk0MzMtNTZkOWNjMTIyM2M4Iiwicm9sZSI6IiJ9.QPyA3SbF5tFnQw8CBrY9EeIZj_mpAfxmpkc0P717YDc

//23039 Guarromán 


class testAEMET {

    

    public static void main(String[] args) {
    	System.setProperty("javax.net.ssl.trustStore","certs/Almacen");
		OkHttpClient client = new OkHttpClient();

		System.out.println("HOLA");

		//Variables
    	String key = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJpdmFudmFsZW5jaWEyN0BnbWFpbC5jb20iLCJqdGkiOiI0MmRjZDJmNS0wNWY0LTQwNzYtOTQzMy01NmQ5Y2MxMjIzYzgiLCJpc3MiOiJBRU1FVCIsImlhdCI6MTU4NzU1MzM5OSwidXNlcklkIjoiNDJkY2QyZjUtMDVmNC00MDc2LTk0MzMtNTZkOWNjMTIyM2M4Iiwicm9sZSI6IiJ9.QPyA3SbF5tFnQw8CBrY9EeIZj_mpAfxmpkc0P717YDc";

    	String cpro_cmun_Guar = "23039"; //Guarromán, Jaén
    	String cpro_cmun_Pel = "49148"; //Peleas de Abajo, Zamora

    	String respuesta_Guar = "";

    	//Petición para Guarromán
    	Request request_Guar = new Request.Builder().url("http://opendata.aemet.es/opendata/api/prediccion/especifica/municipio/diaria/"+ cpro_cmun_Guar +"?api_key="+ key).get().addHeader("cache-control", "no-cache").build();

		try{
			Response response_Guar = client.newCall(request_Guar).execute(); 
			respuesta_Guar = response_Guar.body().string();
		}catch (IOException e){
			System.out.println("Error Guarroman request: "+e);
		}
         System.out.println("EXITO");


        // Segunda petición

        // Extracción de parámetros meteorológicos
        JsonReader lector_Guar = Json.createReader(new StringReader(respuesta_Guar));
		JsonArray raiz_Guar = lector_Guar.readArray(); 

		JsonNumber temp_Guar = raiz_Guar.getJsonObject(0).getJsonObject("prediccion").getJsonArray("dia").getJsonObject(0).getJsonObject("temperatura").getJsonArray("dato").getJsonObject(2).getJsonNumber("value"); 
		System.out.println(temp_Guar);	
		
		//JsonNumber temperatura_PAZ = raiz.getJsonObject(0).getJsonObject("prediccion").getJsonArray("dia").getJsonObject(1).getJsonObject("temperatura").getJsonArray("dato").getJsonObject(2).getJsonNumber("value"); LUIS
        
       

    }
}

/*  System.setProperty("javax.net.ssl.trustStore", "certs/Almacen);
javac -d bin -cp "paquetes/*" src/test/testAEMET.java
java -cp "bin;paquetes/*" test.testAEMET

*/